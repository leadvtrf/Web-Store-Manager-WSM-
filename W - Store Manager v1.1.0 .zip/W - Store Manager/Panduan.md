# Web - Store Manager(WSM) | Panduan
<hr>
<!-- Gunakan MD Viewer untuk melihat ini -->
<div style="padding:8px;border: 1px solid #ff0707; background: #ffbebef8">Catatan: WSM masih dalam pengembangan jadi, masih banyak bug. Jika terdapat masalah, silakan hubungi 0882015268200. Pendapat anda akan membantu kami berkembang 🚀</div>

## PENDAHULUAN

***Panduan ini dibuat agar anda tidak kebingungan saat menggunakan WSM. Panduan ini berisi cara untuk menggunakan semua fitur WSM.***

## 1. Mengganti password dan username saat login

*Jika anda ingin mengganti password dan username, anda dapat membuka file yang berada di res>js>Login.js.*

           ```if (user=="admin" && pass=="123"){
              //Ganti Password Anda Disini```
  
*Di bagian `if (user=="")`, anda bisa mengubah username. sedangkan pada bagian `&& pass==""){`, anda bisa mengubah password.*

## 2. Mengubah data di grafik pendapatan bulanan

*Anda dapat mengubahnya dengan membuka file di res>js>demo>chart-bar-demo.js*

![Gambar 1](res/img/panduangrafik1.jpg)
![Gambar 2](res/img/panduangrafik2.jpg)

*Pada **gambar 1**, anda dapat mengubah bulan dan jumlah penghasilan anda dalam sebulan.*

*Sedangkan pada **gambar 2**, anda dapat mengubah jumlah input maksimal pada grafik pendapatan bulanan.*

## 3. Mengubah data pada tabel stok barang

*Untuk mengubahnya, anda harus membuka file Stok Barang.html di editor kode/teks.*

![Gambar](res/img/panduantabel.jpg)

*Seperti yang anda lihat, **bagian 1** adalah tempat memasukkan judul pada tabel. sedangkan **bagian2** adalah tempat memasukkan detail barang.*

*Untuk menambahkan data barang baru, anda hanya perlu membuat kode pada bagian 2 di baris selanjutnya dengan format:*

```
   <tr>
   <td>Nomor Barang<td>
   <td>Nama Barang<td>
   <td>Harga Barang<td>
   <td>Berat Barang (g, kg, atau ml,l)<td>
   <td>Tanggal Beli<td>
   <td>Jumlah Barang tsb di Toko Anda<td>
   </tr>
```

*Buatlah begitu seterusnya sampai pekerjaan anda selesai😅.*

<hr>

## PENUTUP

**Semoga panduan ini membantu anda agar dapat menggunakan WSM dengan lebih cepat dan efisien👍👍**

<hr>
