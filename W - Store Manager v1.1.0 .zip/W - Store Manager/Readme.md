# Web - Store Manager (WSM) | Readme
<hr>

<div style="padding:8px;border: 1px solid #ff0707; background: #ffbebef8">Catatan: WSM masih dalam pengembangan jadi, masih banyak bug. Jika terdapat masalah, silakan hubungi 0882015268200. Pendapat anda akan membantu kami berkembang 🚀</div>

**Web - Store Manager adalah pengelola toko yang cepat dan lengkap. Berbasis web, membuat alat ini dapat digunakan di berbagai platform seperti Windows, Android, ataupun MacOS.**


## Pembuat

Proyek Ini Dibuat Oleh :
<ul style="list-style:none;">
  <li style="display:flex; flex-direction:row;align-items:center;gap:8px;margin-bottom:8px;">
    <img style="height:77px;width:77px;border-radius:50%;border:1px solid #777777f8" src="https://avatars.githubusercontent.com/u/71929976?v=4" alt="zCraftDeveloper"/>
    <a href="https://github.com/users/leadvtrf" style="text-decoration:none;">zCraftDeveloper (@leadvtrf)</a></li></ul>
    
    
## Kontributor

Proyek ini tidak akan selesai tanpa bantuan mereka

### Gilang Muharom
[Profil]()

### Server.Digital
[Profil]()

#### Mitsuki
[Profil]()

#### Wildy Sheverando
[Profil]()

## Pertanyaan Yang Sering Diajukan
1. Apakah WSM Sepenuhnya Gratis?

 **Untuk saat ini masih gratis, namun di update selanjutnya, saya akan membuat versi pro**
 
2. Berapa Bulan Sekali Biasanya Diadakan Update?

**Biasanya kami melakukan update setiap 1-10 bulan sekali tergantung fitur yang saya tambahkan atau bug yang saya perbaiki**

## Changelog
* V 1.0.0

 *Rilis Pertama di Github*

 *Menambahkan fitur dasar*
* V 1.1.0

 *Menambahkan fitur stok barang*

 *Memperbaiki UI*
 
 *Memperbaiki bug dollar pada grafik batang*
 
 *Memperbaiki readme.md agar dapat diproses github*
* V 1.2.0

 *Menambahkan versi pro*

***Terima Kasib Sudah Mendukung***