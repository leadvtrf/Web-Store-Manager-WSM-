function Login(){ 
            var user = document.getElementById("username").value;
            var pass = document.getElementById("password").value;
             //Ganti Password Anda Di Sini
            if (user=="admin" && pass=="123"){
              //Ganti Password Anda Disini
                window.location.href="/Dashboard.html"
            }else{
                alert("Username dan password anda salah. silakan hubungi admin untuk meminta Pw.");
            }
        }